return {
    "rebelot/kanagawa.nvim"
}