return {
  "williamboman/mason.nvim",
  opts = { ensure_installed = { "sqlfluff" } },
}
